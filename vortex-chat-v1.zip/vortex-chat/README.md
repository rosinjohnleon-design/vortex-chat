# Vortex Chat v1.0

Ein lauffähiges, Discord-inspiriertes Browser-Chat-Grundprojekt mit Node.js, Express und Socket.IO.

## Voraussetzungen
- Node.js 18 oder neuer
- npm

## Starten
1. ZIP entpacken.
2. Terminal im Ordner `vortex-chat` öffnen.
3. `npm install` ausführen.
4. `npm start` ausführen.
5. `http://localhost:3000` im Browser öffnen.

Zum Testen zwei Browserfenster öffnen und unterschiedliche Benutzernamen verwenden.

## Im lokalen Netzwerk
Auf einem zweiten Gerät im selben WLAN `http://DEINE-PC-IP:3000` öffnen. Die Firewall muss Port 3000 erlauben.

## Enthalten
- Echtzeit-Nachrichten in Server-/Textkanälen
- Server und Textkanäle erstellen
- Benutzername und Profilfarbe pro Sitzung
- Online-Liste und Schreibanzeige
- Nachrichtenspeicherung in `data.json` (automatisch erstellt)
- Responsive Benutzeroberfläche

## Wichtige Einschränkungen
Dies ist ein **Demo-Grundprojekt**, kein produktionsreifer Discord-Ersatz. Es gibt **keine Registrierung, Passwortprüfung, Zugriffsrechte, privaten Server, Ende-zu-Ende-Verschlüsselung, Moderation, Datei-Uploads oder Sprach-/Videoanrufe**. Alle angemeldeten Nutzer können alle Server und Kanäle sehen und neue erstellen. Benutzernamen sind nicht verifiziert. Keine privaten oder sensiblen Daten eingeben. Vor öffentlichem Hosting müssen Authentifizierung, Berechtigungen, Rate-Limits, Sicherheitsmaßnahmen, Datenschutz und eine richtige Datenbank ergänzt werden.

## Projektstruktur
- `server.js` – Express, Socket.IO, Speicherung
- `public/index.html` – Oberfläche
- `public/style.css` – Design
- `public/app.js` – Browser-Logik
- `package.json` – Abhängigkeiten und Startbefehl
