const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 100000 });
const DATA = path.join(__dirname, 'data.json');
const defaults = { servers: [{id:'welcome',name:'Vortex Community',channels:[{id:'general',name:'allgemein'},{id:'gaming',name:'gaming'},{id:'ideas',name:'ideen'}]}], messages: [] };
let db;
try { db = JSON.parse(fs.readFileSync(DATA,'utf8')); if (!Array.isArray(db.servers)||!Array.isArray(db.messages)) throw Error(); } catch { db=defaults; }
function save(){ const tmp=DATA+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(db,null,2)); fs.renameSync(tmp,DATA); }
save();
const clean = (s,max) => typeof s==='string' ? s.trim().slice(0,max) : '';
const validName = s => s.length>=2 && s.length<=32 && !/[<>\r\n]/.test(s);
const findServer = id => db.servers.find(s=>s.id===id);
const findChannel = (sid,cid) => findServer(sid)?.channels.find(c=>c.id===cid);
const room = (sid,cid)=>`${sid}:${cid}`;
const users = new Map();
function online(){ return [...users.values()].map(u=>({name:u.name,color:u.color})); }
function broadcastOnline(){io.emit('online',online());}
app.use(express.static(path.join(__dirname,'public')));
app.get('/api/state',(req,res)=>res.json({servers:db.servers}));
io.on('connection',socket=>{
  socket.on('join',({name,color}={},reply=()=>{})=>{
    name=clean(name,32); if(!validName(name)) return reply({error:'Name muss 2 bis 32 Zeichen lang sein.'});
    color=/^#[0-9a-fA-F]{6}$/.test(color)?color:'#5865f2';
    users.set(socket.id,{name,color}); broadcastOnline(); reply({ok:true,servers:db.servers});
  });
  socket.on('enter',({serverId,channelId}={},reply=()=>{})=>{
    if(!users.has(socket.id)) return reply({error:'Bitte zuerst anmelden.'});
    if(!findChannel(serverId,channelId)) return reply({error:'Kanal nicht gefunden.'});
    if(socket.data.room) socket.leave(socket.data.room);
    socket.data.room=room(serverId,channelId); socket.data.serverId=serverId; socket.data.channelId=channelId;
    socket.join(socket.data.room);
    reply({ok:true,messages:db.messages.filter(m=>m.serverId===serverId&&m.channelId===channelId).slice(-100)});
  });
  socket.on('message',(raw={},reply=()=>{})=>{
    const u=users.get(socket.id); if(!u) return reply({error:'Nicht angemeldet.'});
    const text=clean(raw.text,2000); if(!text) return reply({error:'Nachricht ist leer.'});
    if(!socket.data.room || !findChannel(socket.data.serverId,socket.data.channelId)) return reply({error:'Kein Kanal ausgewählt.'});
    const now=Date.now(); if(now-(socket.data.lastMessage||0)<450) return reply({error:'Bitte kurz warten.'});
    socket.data.lastMessage=now;
    const m={id:crypto.randomUUID(),serverId:socket.data.serverId,channelId:socket.data.channelId,name:u.name,color:u.color,text,at:new Date().toISOString()};
    db.messages.push(m); if(db.messages.length>10000)db.messages=db.messages.slice(-10000);
    save(); io.to(socket.data.room).emit('message',m); reply({ok:true});
  });
  socket.on('typing',()=>{const u=users.get(socket.id);if(u&&socket.data.room)socket.to(socket.data.room).emit('typing',{name:u.name});});
  socket.on('createServer',(raw={},reply=()=>{})=>{
    if(!users.has(socket.id))return reply({error:'Nicht angemeldet.'});
    const name=clean(raw.name,32);if(!validName(name))return reply({error:'Servername: 2 bis 32 Zeichen.'});
    if(db.servers.length>=50)return reply({error:'Serverlimit erreicht.'});
    const item={id:crypto.randomUUID(),name,channels:[{id:crypto.randomUUID(),name:'allgemein'}]};
    db.servers.push(item);save();io.emit('servers',db.servers);reply({ok:true,server:item});
  });
  socket.on('createChannel',(raw={},reply=()=>{})=>{
    if(!users.has(socket.id))return reply({error:'Nicht angemeldet.'});
    const s=findServer(raw.serverId), name=clean(raw.name,32).toLowerCase().replace(/\s+/g,'-');
    if(!s||!validName(name)||s.channels.length>=50)return reply({error:'Ungültiger Kanal oder Limit erreicht.'});
    const c={id:crypto.randomUUID(),name};s.channels.push(c);save();io.emit('servers',db.servers);reply({ok:true,channel:c});
  });
  socket.on('disconnect',()=>{users.delete(socket.id);broadcastOnline();});
});
const PORT=Number(process.env.PORT)||3000;
server.listen(PORT,'0.0.0.0',()=>console.log(`Vortex Chat läuft auf http://localhost:${PORT}`));
